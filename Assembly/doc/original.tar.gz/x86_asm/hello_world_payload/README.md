# x86_asm - Hello World Shellcode
Code samples and Makefile for blog posts related to porting the Hello World program into shellcode viable as an exploit payload.

# Related Blog Posts to This Code:
* [Linux X86 Assembly – How to Make Our Hello World Usable as an Exploit Payload](https://secureideas.com/blog/2021/06/linux-x86-assembly-how-to-make-our-hello-world-usable-as-an-exploit-payload.html)
